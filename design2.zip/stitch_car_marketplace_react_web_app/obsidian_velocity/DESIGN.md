---
name: Obsidian Velocity
colors:
  surface: '#131318'
  surface-dim: '#131318'
  surface-bright: '#39393e'
  surface-container-lowest: '#0e0e13'
  surface-container-low: '#1b1b20'
  surface-container: '#1f1f24'
  surface-container-high: '#2a292f'
  surface-container-highest: '#35343a'
  on-surface: '#e4e1e9'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e4e1e9'
  inverse-on-surface: '#303035'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#b4c5ff'
  on-secondary: '#002a78'
  secondary-container: '#0053db'
  on-secondary-container: '#cdd7ff'
  tertiary: '#a4c9ff'
  on-tertiary: '#00315d'
  tertiary-container: '#4c93e7'
  on-tertiary-container: '#002a51'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#d4e3ff'
  tertiary-fixed-dim: '#a4c9ff'
  on-tertiary-fixed: '#001c39'
  on-tertiary-fixed-variant: '#004883'
  background: '#131318'
  on-background: '#e4e1e9'
  surface-variant: '#35343a'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-spec:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system defines a high-trust, premium automotive marketplace built for peer-to-peer buying and selling. It balances high-performance aesthetics with transaction transparency and institutional confidence. The experience evokes the precision, power, and prestige of modern automotive engineering while maintaining extreme consumer clarity.

The visual style blends **Contemporary Dark Minimalism** with **Atmospheric Layering**:
- Deep obsidian and charcoal backdrops evoke luxury vehicle showrooms and low-light studio photography.
- High-vibrancy electric blue signals technology, authentication, and speed.
- Micro-delicacy in borderlines (#272732) and soft atmospheric glows prevents pure dark-mode starkness, grounding listings in dimensional space.
- Clean, open geometry in buttons, cards, and metadata badges communicates mechanical reliability and modern digital finance.

## Colors

The palette revolves around deep pitch and obsidian foundation layers punctuated by crisp electric blues and automotive-grade functional status hues.

### Foundation & Surfaces
- **Canvas Base (`#0A0A0C`):** Root background tone providing complete immersion without pure `#000000` clipping.
- **Surface Elevation 1 (`#111116`):** Primary card, shelf, and header background.
- **Surface Elevation 2 (`#181820`):** Floating controls, interactive cards on hover, and dropdown dialogs.
- **Surface Elevation 3 (`#22222D`):** Active toggles, elevated chip pills, and modal containers.
- **Border Stroke (`#272732`):** Subtle defining stroke for structural boundaries and separators.

### Primary Accents & Energy
- **Primary Electric Blue (`#3B82F6`):** The primary interaction driver used for main CTAs, active states, key data highlights, and branded typography flourishes.
- **Primary Deep Hover (`#2563EB`):** Pressed and active hover state for primary controls.
- **Secondary Sky Tone (`#60A5FA`):** High-contrast text highlights, price emphasis, verified indicators, and link states against deep black.

### Neutral Typography
- **Headings & Primary Labels:** `#FFFFFF` (100% white) for uncompromised legibility and high contrast.
- **Secondary Text & Specs:** `#94A3B8` (Slate-400) for vehicle mechanical specifications, timestamps, and secondary metadata.
- **Muted & Placeholders:** `#64748B` (Slate-500) for input prompts, inactive tab states, and unselected chips.

## Typography

The typographic strategy utilizes **Plus Jakarta Sans** for expressive, bold, and authoritative display headings paired with **Inter** for dense spec sheets, numeric vehicle telemetry, and transactional copy.

### Hierarchy & Usage
- **Hero Title (`display-hero`):** Uppercase and tight letter-spacing for landing statements. Combine pure white text with inline electric blue keywords (e.g., "FIND YOUR NEXT / DREAM CAR").
- **Vehicle Card Titles (`headline-md`):** High contrast white, set at 20px semi-bold, maintaining scannability across grid layouts.
- **Pricing Indicators:** Bold weight using `headline-md` or `headline-lg`, applying the primary electric blue (`#60A5FA` / `#3B82F6`) to the rupee sign (`₹`) and numerical value with clean body tracking on the unit (e.g., `₹12.4 Lakh`).
- **Vehicle Spec Labels (`label-spec`):** High legibility at compact dimensions, formatted in Title Case or Uppercase with muted slate styling (`#94A3B8`).

## Layout & Spacing

The layout embraces a wide, cinematic format with maximum horizontal screen presence to prioritize vehicle photography.

### Grid System
- **Desktop (1280px+):** 12-column responsive fluid grid with 1.5rem (24px) gutters and a max-width container of 1440px. Section margins extend to 3rem (48px) for breathing room.
- **Tablet (768px – 1024px):** 8-column grid with 1rem (16px) gutters and 2rem margins.
- **Mobile (320px – 767px):** 4-column fluid layout with 1rem gutters and 1.25rem outer edge margins.

### Spacing Philosophy
- **Component Padding:** Standard card interior padding is set to `space-lg` (24px) on desktop and `space-md` (16px) on mobile.
- **Spec Clusters:** Badge and metadata rows use micro-spacing (`space-xs` and `space-sm`) between icons and spec values to ensure tight association without clutter.
- **Vertical Rhythm:** Sections on landing and discovery pages are separated by `space-xl` (40px) or double increments for dramatic theatrical separation.

## Elevation & Depth

Visual hierarchy on dark surfaces is maintained through a combination of structured luminous borders and soft optical backdrops rather than muddy dark shadows.

### Tonal Elevation Stack
- **Level 0 (Canvas):** Pure base (`#0A0A0C`). Holds background graphic spotlights and city silhouettes.
- **Level 1 (Card & Shelf):** Surface `#111116` bordered with 1px solid `#272732`. Used for car grid cards and search bar containers.
- **Level 2 (Hover & Overlays):** Surface `#181820` with a 1px border highlighted to `#3B82F6` at 30% opacity. Accompanied by a subtle ambient glow: `0px 8px 24px -4px rgba(59, 130, 246, 0.12)`.
- **Level 3 (Modals & Flyouts):** Surface `#181820` with full backdrop blur (`backdrop-filter: blur(16px)`) and a hairline stroke `#3B82F6` (50% opacity).

### Glassmorphism & Light Accents
- Translucent navbars utilize `rgba(10, 10, 12, 0.8)` with `backdrop-filter: blur(12px)` and a subtle bottom stroke of `#272732`.
- Hero photography leverages a central radial ambient gradient (`radial-gradient(circle at 60% 40%, rgba(59, 130, 246, 0.08) 0%, transparent 60%)`) directly behind showcase vehicles to sculpt their silhouette against the dark landscape.

## Shapes

The design uses a **Rounded** shape language (`roundedness: 2`), balancing aerodynamic curves with clean structural edges.

### Geometry Breakdown
- **Vehicle Showcase Cards:** Styled with `rounded-2xl` (16px) outer radii. Thumbnail image headers must inherit the top rounding (`border-top-left-radius: 16px`, `border-top-right-radius: 16px`) with zero radius at the bottom to transition seamlessly into the metadata panel.
- **Interactive Badges & Meta Chips:** Completely pill-shaped (`rounded-full` / 9999px) to contrast with card rectilinearity and evoke automotive dashboard indicators.
- **Search Bars & Primary Action Buttons:** Fully pill-shaped or soft-rounded (`rounded-full` for search inputs and standard hero buttons; `rounded-xl` for form controls) for touch and click comfort.
- **Checkboxes & Segment Controls:** Soft-cornered `rounded-md` (6px to 8px) to feel crisp and mechanical.

## Components

### Buttons
- **Primary CTA:** Background `#3B82F6`, text `#FFFFFF`, font `label-lg`, `rounded-full` pill structure with horizontal padding of 24px and height of 48px. Includes a subtle icon slot (e.g., car icon, arrow). Active hover transitions to `#2563EB` with an ambient glow (`box-shadow: 0 0 16px rgba(59, 130, 246, 0.4)`).
- **Secondary Ghost CTA:** 1px border of `#3B82F6` or `#272732`, transparent background, text `#FFFFFF`, with smooth fill transition to `#181820` on hover.
- **Tertiary / Utility:** Frameless, text `#94A3B8`, transitioning to `#60A5FA` on hover.

### Search Bar
- **Global Header Search:** Pill container (`rounded-full`) with surface `#111116`, border 1px `#272732`, height 44px, leading search icon in `#94A3B8`, placeholder text in `#64748B`. Focus state transitions the border to `#3B82F6` with a delicate 2px blue ring.

### Vehicle Specification Chips & Badges
- Pill-shaped tokens (`rounded-full`) styled with micro surface `#181820` and hairline border `#272732`.
- Content contains an automotive glyph (fuel pump, manual transmission gate, seat count, vehicle profile) in `#60A5FA` followed by concise text (e.g., "SUV", "Manual", "Petrol", "4 Seater") in `#94A3B8`.

### Vehicle Marketplace Card
- **Container:** Background `#111116`, border 1px solid `#272732`, radius `rounded-2xl`, overflow hidden.
- **Top Image Box:** 16:9 or 4:3 high-resolution vehicle photograph on a dark gradient background. Top corners rounded to match container.
- **Meta Bar:** Horizontal row directly beneath the image featuring spec items separated by subtle spacing or divider bullets.
- **Footer Information:** Flex row with the vehicle model name (e.g., "Hyundai Creta") on the left (`headline-md`, white) and bold price tag on the right (e.g., "₹12.4 lakh" with the number in `#60A5FA`).

### Filter Chips & Sliders
- **Filter Chips:** Unselected state `#181820` with `#272732` border. Selected state `#3B82F6` background with `#FFFFFF` text.
- **Price Range Slider:** Track background `#272732`, active track filled with `#3B82F6`, thumb control 18px circle in white with electric blue outline.